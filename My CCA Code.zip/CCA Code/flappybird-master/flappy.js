// the Game object used by the phaser.io library
var stateActions = { preload: preload, create: create, update: update };

// Phaser parameters:
// - game width
// - game height
// - renderer (go for Phaser.AUTO)
// - element where the game will be drawn ('game')
// - actions on the game state (or null for nothing)
var game = new Phaser.Game(790, 500, Phaser.AUTO, 'game', stateActions);
var pipes = []
var score=0;
var labelScore;
var player;
var gameinterval = 1.75 * Phaser.Timer.SECOND

/*
 * Loads all resources for the game and gives them names.
 */
function preload() {
  game.load.image("birdy", "../assets/birdysprite.png");
  game.load.audio("score", "../assets/point.ogg");
  game.load.image("pipeBlock","../assets/pipe.png");
  game.load.image("backdrop", "../assets/FlappyBackground.png");

}

/*
 * Initialises the game. This function is only called once.
 */
function create() {
  game.physics.startSystem(Phaser.Physics.ARCADE);
  game.add.image(0, 0, "backdrop");
    // set the background colour of the scene
  game.add.text(0, 0, "Welcome to Annoyed Bird",{font:"35px Arial", fill: "#971dad"});
    //Text

  game.input.onDown.add(clickHandler);
  game.input
      .keyboard.addKey(Phaser.Keyboard.SPACEBAR)
      .onDown.add(spaceHandler);
    //Sound is played here

   labelScore = game.add.text(20, 60, "0",
   {font: "30px Arial", fill: "#FFFFFF"});
   //The score

   player= game.add.sprite(200,200,"birdy");

   //game.input.keyboard.addKey(Phaser.Keyboard.RIGHT)
                      //.onDown.add(moveRight);

  // game.input.keyboard.addKey(Phaser.Keyboard.LEFT)
                      //.onDown.add(moveLeft);

   //game.input.keyboard.addKey(Phaser.Keyboard.DOWN)
                      //.onDown.add(moveDown);

   //game.input.keyboard.addKey(Phaser.Keyboard.UP)
                      //.onDown.add(moveUp);
   game.physics.arcade.enable(player);
   player.body.gravity.y = 300;
   game.input.keyboard
       .addKey(Phaser.Keyboard.SPACEBAR)
       .onDown
       .add(playerJump);
    //Making the birdy jump

    var pipeInterval = 1.75 * Phaser.Timer.SECOND;
    game.time.events.loop(
      pipeInterval,
      generatePipe
    );
generatePipe();
}

/*
 * This function updates the scene. It is called for every new frame.
 */
function update() {
  game.physics.arcade.overlap(
    player,
    pipes,
    gameOver);
}

function clickHandler(event) {
  //alert("Click To Start");
  //alert("3")
  //alert("2")
  //alert("1")
  //alert("GO")
  //alert("The position is: " + event.x + "," + event.y);
  //game.add.sprite(event.x, event.y, "birdy");
}
function spaceHandler() {
  game.sound.play("score");
}
function changeScore(){

  score++;
  labelScore.setText(score.toString());
}

function moveRight(){
  player.x+=100;
}
function moveLeft(){
  player.x-=100;
}
function moveUp(){
  player.y-=100;
}
function moveDown(){
  player.y+=100;
}
function generatePipe() {
  var gapStart = game.rnd.integerInRange(1, 7);
  //random gap
  for(var count=0; count<100; count+=1){
    if(count !=gapStart && count != gapStart + 1){
    addPipeBlock(700, 50*count);


//Generating Pipes Here
}
}
changeScore();
}
function addPipeBlock(x,y){
//Create a new pipe block
  var pipeBlock = game.add.sprite(x,y, "pipeBlock");
  //insert it into the 'pipes' array
  pipes.push(pipeBlock);
  game.physics.arcade.enable(pipeBlock);
  pipeBlock.body.velocity.x=-150;
}
function playerJump() {
  player.body.velocity.y = -200;
}
function gameOver(){
  game.stage.setBackgroundColor("#000000");
  game.add.text(130, 200, "Unlucky Try Again",{font:"60px Arial", fill: "#971dad"});
  game.paused = true;
  game.input.keyboard
      .addKey(Phaser.Keyboard.SPACEBAR)
      .onDown
      .add(unpause);
  location.reload();
}
function unpause(){
  game.paused = false
}

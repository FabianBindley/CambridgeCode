class RGBA{
  constructor(redValue, greenValue, blueValue, alphaValue){
    this.red = redValue;
    this.green = greenValue;
    this.blue = blueValue;
    this.alpha = alphaValue;
  }
}

var colour = new RGBA(0, 0, 255, 255);
var purpleColour = new RGBA(195, 0, 255, 255);
//alert(colour.blue);
alert("There is " + purpleColour.green + " green in purple colour");
alert("There is " + purpleColour.red + " red in purple colour");
alert("There is " + purpleColour.blue + " blue in purple colour");

console.log(colour.red);
console.log(colour.green);

class ImageUtils {

    static getCanvas(w, h) {
        var c = document.querySelector("canvas");
        c.width = w;
        c.height = h;
        return c;
    }

    static getPixels(img) {
        var c = ImageUtils.getCanvas(img.width, img.height);
        var ctx = c.getContext('2d');
        ctx.drawImage(img, 0, 0);
        return ctx.getImageData(0,0,c.width,c.height);
    }

    static putPixels(imageData, w, h) {
        var c = ImageUtils.getCanvas(w, h);
        var ctx = c.getContext('2d');
        ctx.putImageData(imageData, 0, 0);
    }

}

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function colourisePixel(originalRGBA, colour, level) {
  var diffRed = (originalRGBA.red - colour.red) * (level / 100);
  var newRed = originalRGBA.red - diffRed;

    var diffGreen = (originalRGBA.green - colour.green) * (level / 100);
    var newGreen = originalRGBA.green - diffGreen;

    var diffBlue = ((originalRGBA.blue - colour.blue) * (level / 100));
    var newBlue = originalRGBA.blue - diffBlue;

    return new RGBA(newRed, newGreen, newBlue, originalRGBA.alpha); }


function colourise(img, colour, level){

  var pixels = ImageUtils.getPixels(img);
  var all = pixels.data.length;
  var data = pixels.data;


  for ( var i = 0; i < all; i += 4){
    var originalRGBA = new RGBA(data[i], data[i+1], data[i+2], data[i+3]);
    var modifiedRGBA = colourisePixel(originalRGBA, colour, level);
    setPixel(data, i, modifiedRGBA);
  }

function setPixel(data, i, colour) {
      data[i] = colour.red;
      data[i+1] = colour.green;
      data[i+2] = colour.blue;
      data[i+3] = colour.alpha;
    }

  ImageUtils.putPixels(pixels, img.width, img.height);
}
// function definitions here
function sepiaPixel(colour){

var modifiedRed = colour.red * 0.393 + colour.green * 0.769 + colour.blue * 0.189;
var modifiedGreen = colour.red * 0.349 + colour.green * 0.686 + colour.blue * 0.168;
var modifiedBlue = colour.red * 0.272 + colour.green * 0.534 + colour.blue * 0.131;

return new RGBA (modifiedRed, modifiedGreen, modifiedBlue, colour.alpha);

}

function sepia(img) {
    var pixels = ImageUtils.getPixels(img);
    var all = pixels.data.length;
    var data = pixels.data;
    for (var i = 0; i < all;i += 4) {
      var originalRGBA = new RGBA(data[i], data[i+1], data[i+2], data[i+3]);
      var sepiaRGBA = sepiaPixel(originalRGBA);

      data[i] = sepiaRGBA.red;
      data[i+1] = sepiaRGBA.green;
      data[i+2] = sepiaRGBA.blue;
      data[i+3] = sepiaRGBA.alpha;    }

    ImageUtils.putPixels(pixels, img.width, img.height);
  }


$(document).ready(function() {
    var img = new Image();
    img.src = "img/datboi.jpg";
    //colourise(img, colour, 20);
    sepia(img);



});

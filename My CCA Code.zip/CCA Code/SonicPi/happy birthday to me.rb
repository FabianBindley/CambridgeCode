/Happy birthday/


define :dded do
  play 62, release:0.8
  sleep 0.5
  play 62, release:0.8
  sleep 0.3
  play 64, release:1
  sleep 0.75
  play 62, release:1
  sleep 0.75
end

define :gf do
  play 67, release:0.8
  sleep 0.75
  play 66, release:1
  sleep 1.5
end

define :ag do
  play 69
  sleep 0.8
  play 67
  sleep 2
end

define :dddbgfe do
  play 62, release: 0.75
  sleep 0.6
  play 62, release: 0.75
  sleep 0.6
  play 75, release: 0.75
  sleep 0.6
  play 71, release: 0.75
  sleep 0.7
  play 67, release: 0.75
  sleep 0.7
  play 66, release: 0.75
  sleep 0.7
  play 64, release: 1
  sleep 1
end

define :ccbfgag do
  play 72
  sleep 0.5
  play 72
  sleep 0.5
  play 71
  sleep 0.7
  play 67
  sleep 0.6
  play 69
  sleep 0.8
  play 67
  sleep 1
end

dded
gf
dded
ag
dddbgfe
ccbfgag

